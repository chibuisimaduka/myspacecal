<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author larry
 * */

Route::get('(:bundle)/schedule/get/(:any?)', array('uses' => 'home::home@schedules'));




Route::controller(Controller::detect('home'));
?>
