<?php namespace Croppa;

class Exception extends \Exception { }
