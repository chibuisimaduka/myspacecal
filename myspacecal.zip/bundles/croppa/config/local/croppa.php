<?php return array(
	
	// Locally, make no restrictions
	'max_crops' => false,
	
);