<?php

return array(

	'required' => 'El campo de atributo es necesario.',

);