@layout('home::templates.hometemplate')


@section('content')
<script type ="text/javascript">
    (function ($) {
 $.fn.vAlign = function(fn) {

 return this.each(

 function(i){

 var ah = $(this).width();
 var ph = $(this).parent().width();
 var mh = Math.ceil((ph-ah) / 2);
 var perc = Math.ceil((mh/ph) * 100);
 $(this).css('margin-left',perc + "%");
 });
 };
})(jQuery);
$(document).ready(function(){
 $('.flexslider').vAlign();
 $(window).resize(function() {
 $('.flexslider').vAlign();
});
});
    </script>
<div id="highlighted">
    <div class="inner">
        <!--
        Flexslider
        - May use standard Bootstrap markup within slides
        - For best results use images all the same size (in this example they are 600px x 400px)
        -->
        <!--Flexslider Showshow-->
        <section class="flexslider-wrapper container">
            <div class="flexslider span8" style="position: center" data-slidernav="auto" data-transition="slide">
                <!--The Slides-->
                <div class="slides">

                    <!--Slide #1 with caption-->
                    <div class="slide row-fluid">                
                        <div>{{HTML::image('img/pic5.png', 'Phones We unlock');}}</div>

                    </div>

                    <!--Slide #2 with caption-->
                    <div class="slide row-fluid">                
                        <div>{{HTML::image('img/pic6.png', 'We unlock them all');}}</div>

                    </div>

                    <!--Slide #3 & so on below-->
                    <div class="slide row-fluid">                
                        <div>{{HTML::image('img/pic7.png', 'We unlock them all');}}</div>               
                    </div>
                    <!--Slide #3 & so on below-->
                    <div class="slide row-fluid">                
                        <div>{{HTML::image('img/pic8.png', 'We unlock them all');}}</div>               
                    </div>

                </div>
            </div>             
        </section>        
    </div>
</div>


<div id="content">
    <div class="container">
        <!-- Mission statement -->
        <div class="row-fluid mission">
            <div class="inner">
                <h3>We unlock Phones <span>Iphones, HTCs</span> and Many More...! <small><a href="services.htm">Find out more</a></small></h3>
            </div>
        </div>
        <!--Logo & Intro--->

        <div class="block services margin-top-large" >
            <div style ="margin: 0 auto 0"">
            <h2>Why Genius Unlock?</h2>
                <div class="span12">
                    {{HTML::image('img/genunlocklogo.png', 'Coverage Image',array('align'=>'left'));}}
                    <p class="span8" >    
                        GeniusUnlock is the leader in unlocking mobile phones with remote codes worldwide. 
                        With the lowest prices, fastest turnaround times and superior customer service we have grown to be the 
                        top amongst our peers in the industry across the globe. We are a direct source and not a third party provider 
                        for all your unlocking needs. By using our mobile phone unlocking services, you will be able to use your phone 
                        with any network carriers worldwide without any restrictions. Every cell phone has a unique unlock code.
                        By submitting your IMEI number, we are able to generate your specific unlock code.
                        Once you have the code you simply enter it into your phone and it will be unlocked. 
                        That's it! There is no need to send in your Phone. No Cables! No Software! No Hassle!</p>
                </div>
            </div>
        </div>
    
    <!-- Services -->
    <div class="block services margin-top-large">
        <h2 class="block-title"><span>Our Services</span> <small><a href="services.htm">View all</a></small></h2>
        <ul class="thumbnails">

            <li class="span3">
                <h3 class="title"><a href="{{URL::to('/home/home/services')}}" target ="_blank"><i class="icon-ok-sign icon-small icon-inverse-80 icon-circle"></i> Unlock Your Phone</a></h3>
                <p>Unlocking your Phone is now easier than ever!! All it takes is a few steps and you're well on your way to phone freedom! Click on the button below to proceed.<br><br><a class="btn pull-right" href ="{{URL::to('/home/home/services')}}" target ="_blank"><i class="icon-ok-sign"></i>Unlock Phone &raquo</a> </p>
            </li>

            <li class="span3">
                <h3 class="title"><a href="http://www.checkesnfree.com/ target ="_blank""><i class="icon-search icon-small icon-inverse-80 icon-circle"></i> Check ESN</a></h3>
                <p>Not sure about your phone's ESN Number? No problem... You can always look it up and find information about it... Click on the button below to check your ESN Number.<br><br><a class="btn pull-right" href ="http://www.checkesnfree.com/" target ="_blank"><i class="icon-search"></i>Check ESN &raquo</a></p>
            </li>

            <li class="span3">
                <h3 class="title"><a href="https://selfsolve.apple.com/agreementWarrantyDynamic.do" target ="_blank"><i class="icon-check icon-small icon-inverse-80 icon-circle"></i> iPhone Warranty Status</a></h3>
                <p>Not sure about your iPhone's Warranty status? Well we're here to help... Click the button and follow the instructions to find out your phone's status. <br><br><br><a class="btn pull-right" href ="https://selfsolve.apple.com/agreementWarrantyDynamic.do" target ="_blank"><i class="icon-check"></i>Check Status &raquo</a></p>
            </li>


            <li class="span3">
                <h3 class="title"><a href="services.htm"><i class="icon-thumbs-up icon-small icon-inverse-80 icon-circle"></i> Unlock Instructions</a></h3>
                <p >Do you want to find out more about what we do? You can always check out our Services for more information on what we do... Any comments and reviews are welcome on the review page.<br> <a class="btn pull-right" href ="#"><i class="icon-thumbs-up"></i>Unlock Instructions &raquo</a> </p>
            </li>            
        </ul>
    </div>


    <!-- Mission Stat-->
    <div class="block services margin-top-large">
        <h2 class="block-title"><span>What's New?</span> <small><a href="services.htm">Other stuff...</a></small></h2>
        <ul class="thumbnails">
            <li class="span6">
                <div>

                    <h4><a href="services.htm">New Services!</a></h4>

                    <p> Genius Unlock now offers a permanent iPhone IMEI unlock solution for all AT&T, Verizon and international iPhone models!
                        Genius Unlock iPhone IMEI unlock is a permanent iPhone unlock solution. Once unlocked, your iPhone will remain unlocked even after an iOS upgrade.
                    </p>
                    <h4><a href="#">Coverage</a></h4>
                    <p>
                        {{HTML::image('img/coverage.png', 'Coverage Image',array('align'=>'left'));}}

                        Genius Unlock has broad coverage covering multiple networks across many nations.
                </div>

            </li>
            <li class="span6">
                <div>

                    <h4><a href="services.htm">100% Money Back Guarantee!</a></h4>
                    <p>We offer our customers a 100% money back guarantee because we are a legitimate service provider.
                        Our 100% money back guarantee applies to IMEI's that are not found or is NOT blacklisted or barred.
                        We DO NOT offer this money back guarantee if you submit the wrong carrier network to us, 
                        your IMEI is blacklisted/barred or you changed your mind.</p>
                    <h4><a href="#">iPhone IMEI Unlock Instruction</a></h4>
                    <p>
                        These codes are retrieved from a database. If the code is not available, the order will come back as "NOT FOUND" and your account will be refunded.
                        Our system will return the unlock code status as "UNLOCKED", once you receive this you may then plug your iPhone into iTunes and iTunes will ask you to update the iPhone, perform the update and the iphone will be unlocked.
                        If your iPhone has already been updated before and there is no other update available, then back up your iPhone first and then click on "RESTORE" on iTunes and iPhone will be unlocked with the message popping up on iTunes screen saying ..

                        <br><b>"Congratulations, Your iPhone has been unlocked".</b>
                    </p>

                </div>
            </li>
        </ul>


    </div>
</div>
</div>



    <!-- portfolio -->
    <!-- Recommended screenshot size: 400px x 300px -->
    <!--
                    <div class="block portfolio margin-top-large">
                        <h2 class="block-title"><span>Our Work</span> <small><a href="portfolio.htm">View all</a></small></h2>
                        <ul class="thumbnails projects">
    
                            <li class="span4 ">
                                <a href="portfolio-project.htm"><img src="img/portfolio/enkel-home-blue.png" alt="Blue Theme" class="img-polaroid" /></a>
                                <h3 class="title"><a href="portfolio-project.htm">Blue Theme</a><small class="pull-right"></small></h3>
                                <p class="muted">Rhoncus adipiscing, magna integer cursus augue eros lacus porttitor magna.</p>
                            </li>    
    
                            <li class="span4 ">
                                <a href="portfolio-project.htm"><img src="img/portfolio/enkel-home-colours.png" alt="Colour Variations" class="img-polaroid" /></a>
                                <h3 class="title"><a href="portfolio-project.htm">Colour Variations</a><small class="pull-right"></small></h3>
                                <p class="muted">Rhoncus adipiscing, magna integer cursus augue eros lacus porttitor magna.</p>
                            </li>    
    
                            <li class="span4 ">
                                <a href="portfolio-project.htm"><img src="img/portfolio/enkel-services-green.png" alt="Services Green" class="img-polaroid" /></a>
                                <h3 class="title"><a href="portfolio-project.htm">Services Green</a><small class="pull-right"></small></h3>
                                <p class="muted">Rhoncus adipiscing, magna integer cursus augue eros lacus porttitor magna.</p>
                            </li>    
                        </ul>
                    </div>     
                </div>
            </div>-->
    <!--
            <div id="content-below" class="wrapper">
                <div class="container">
                    <div class="clients block">
                        <h3 class="block-title"><span>Clients</span></h3>
    <!--Recommended image sizing: 170px & 70px-->
    <!--
    <ul class="thumbnails">
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="HTML 5" title="HTML 5"><img src="img/clients/html5.png" class="img-rounded" alt="HTML 5 logo" /></a></li>
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="CSS 3" title="CSS 3"><img src="img/clients/css3.png" class="img-rounded" alt="CSS 3 logo" /></a></li>
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="Git Hub" title="Git Hub"><img src="img/clients/github.png" class="img-rounded" alt="Git Hub logo" /></a></li>
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="Amazon" title="Amazon"><img src="img/clients/amazon.png" class="img-rounded" alt="Amazon logo" /></a></li>
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="Android" title="Android"><img src="img/clients/android.png" class="img-rounded" alt="Android logo" /></a></li>
        <li class="span2"><a href="http://themelize.me" class="_tooltip" data-placement="top" data-original-title="BBC" title="BBC"><img src="img/clients/bbc.png" class="img-rounded" alt="BBC logo" /></a></li>
    </ul> 
</div>
</div>
</div>-->
    @endsection

